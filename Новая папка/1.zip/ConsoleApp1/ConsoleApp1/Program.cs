﻿int n1 = 3;
int n2 = 5;

int result = n2 * 3 - 40 / 2 * n1--;
Console.WriteLine(result);

int step1 = n2* 3;
Console.WriteLine(step1);

int step2 = 40 / 2;
Console.WriteLine(step2);

int step3 = n1--;
Console.WriteLine(step3);

int step4 = step2 * step3;
Console.WriteLine(step4);

int step5 = step1 - step4;
Console.WriteLine(step5);*/


int num1 = 4;
int num2 = 5;
int num3 = 15;
int num4 = 12;
int num5 = 5;
int result = 11;

Console.WriteLine(result += num2 * num1 + num3 % num5 / num4);

int step1 = num2 * num1;
Console.WriteLine(step1);

int step2 = num3 % num5;
Console.WriteLine(step2);   

int step3 = step2 / num4;
Console.WriteLine(step3);

int step4 = step1 + step3;
Console.WriteLine(step4);


int x = 8;
int y = 11;

int z = x++ + ++y;

Console.WriteLine(z);